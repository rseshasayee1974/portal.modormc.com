<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('usage_logs', function (Blueprint $table): void {
            $table->unsignedBigInteger('entity_id')->nullable()->after('user_id');
            $table->unsignedBigInteger('plant_id')->nullable()->after('entity_id');
            $table->index(['user_id', 'entity_id', 'plant_id', 'module', 'created_at'], 'usage_logs_scope_idx');
        });

        Schema::table('usage_summaries', function (Blueprint $table): void {
            $table->unsignedBigInteger('entity_id')->nullable()->after('user_id');
            $table->unsignedBigInteger('plant_id')->nullable()->after('entity_id');
            $table->dropUnique('usage_summaries_user_module_date_unique');
            $table->unique(
                ['user_id', 'entity_id', 'plant_id', 'module', 'date'],
                'usage_summaries_scope_unique'
            );
            $table->index(['user_id', 'entity_id', 'plant_id', 'month', 'module'], 'usage_summaries_scope_idx');
        });

        Schema::table('billings', function (Blueprint $table): void {
            $table->unsignedBigInteger('entity_id')->nullable()->after('user_id');
            $table->unsignedBigInteger('plant_id')->nullable()->after('entity_id');
            $table->dropUnique('billings_user_month_unique');
            $table->unique(['user_id', 'entity_id', 'plant_id', 'month'], 'billings_scope_unique');
            $table->index(['user_id', 'entity_id', 'plant_id', 'status'], 'billings_scope_status_idx');
        });
    }

    public function down(): void
    {
        Schema::table('billings', function (Blueprint $table): void {
            $table->dropIndex('billings_scope_status_idx');
            $table->dropUnique('billings_scope_unique');
            $table->unique(['user_id', 'month'], 'billings_user_month_unique');
            $table->dropColumn(['entity_id', 'plant_id']);
        });

        Schema::table('usage_summaries', function (Blueprint $table): void {
            $table->dropIndex('usage_summaries_scope_idx');
            $table->dropUnique('usage_summaries_scope_unique');
            $table->unique(['user_id', 'module', 'date'], 'usage_summaries_user_module_date_unique');
            $table->dropColumn(['entity_id', 'plant_id']);
        });

        Schema::table('usage_logs', function (Blueprint $table): void {
            $table->dropIndex('usage_logs_scope_idx');
            $table->dropColumn(['entity_id', 'plant_id']);
        });
    }
};
