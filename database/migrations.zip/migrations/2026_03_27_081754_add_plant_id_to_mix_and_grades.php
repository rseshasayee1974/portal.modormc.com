<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('mix_designs', function (Blueprint $table) {
            if (!Schema::hasColumn('mix_designs', 'plant_id')) {
                $table->foreignId('plant_id')->after('id')->nullable()->constrained('plants')->nullOnDelete();
            }
        });

        Schema::table('mix_design_items', function (Blueprint $table) {
            if (!Schema::hasColumn('mix_design_items', 'plant_id')) {
                $table->foreignId('plant_id')->after('id')->nullable()->constrained('plants')->nullOnDelete();
            }
        });

        Schema::table('concrete_grades', function (Blueprint $table) {
            if (!Schema::hasColumn('concrete_grades', 'plant_id')) {
                $table->foreignId('plant_id')->after('id')->nullable()->constrained('plants')->nullOnDelete();
            }
        });

        Schema::table('concrete_grade_items', function (Blueprint $table) {
             if (!Schema::hasColumn('concrete_grade_items', 'plant_id')) {
                $table->foreignId('plant_id')->after('id')->nullable()->constrained('plants')->nullOnDelete();
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('mix_designs', function (Blueprint $table) {
            $table->dropForeign(['plant_id']);
            $table->dropColumn('plant_id');
        });

        Schema::table('mix_design_items', function (Blueprint $table) {
            $table->dropForeign(['plant_id']);
            $table->dropColumn('plant_id');
        });

        Schema::table('concrete_grades', function (Blueprint $table) {
            $table->dropForeign(['plant_id']);
            $table->dropColumn('plant_id');
        });

        Schema::table('concrete_grade_items', function (Blueprint $table) {
            $table->dropForeign(['plant_id']);
            $table->dropColumn('plant_id');
        });
    }
};
