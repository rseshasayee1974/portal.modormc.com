<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mm_mix_design_materials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mix_design_id')->constrained('mm_mix_designs')->cascadeOnDelete();
            $table->string('material_name');
            $table->decimal('qty_per_m3', 12, 3);
            $table->foreignId('uom_id')->constrained('mm_product_units')->cascadeOnDelete();

            $table->foreignId('created_by')->nullable()->constrained('mm_users');
            $table->foreignId('updated_by')->nullable()->constrained('mm_users');
            $table->foreignId('deleted_by')->nullable()->constrained('mm_users');

            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mm_mix_design_materials');
    }
};
