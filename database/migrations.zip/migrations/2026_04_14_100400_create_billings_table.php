<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('billings', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('month', 7);
            $table->decimal('total_amount', 12, 4)->default(0);
            $table->json('breakdown_json');
            $table->string('status', 20)->default('pending');
            $table->timestamps();

            $table->unique(['user_id', 'month'], 'billings_user_month_unique');
            $table->index(['user_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('billings');
    }
};
