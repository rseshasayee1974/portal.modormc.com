<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mm_mix_designs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('plant_id')->constrained('mm_plants');
            $table->string('grade');
            $table->string('design_code')->unique();
            $table->string('design_name');
            $table->boolean('is_active')->default(true);

            $table->foreignId('created_by')->nullable()->constrained('mm_users');
            $table->foreignId('updated_by')->nullable()->constrained('mm_users');
            $table->foreignId('deleted_by')->nullable()->constrained('mm_users');

            $table->timestamps();
            $table->softDeletes();

            $table->index(['plant_id', 'grade']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mm_mix_designs');
    }
};
