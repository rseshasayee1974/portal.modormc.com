<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mm_dispatches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('work_order_id')->constrained('mm_work_orders');
            $table->foreignId('batch_id')->constrained('mm_batches');
            $table->foreignId('truck_id')->constrained('mm_machines');
            $table->foreignId('driver_id')->nullable()->constrained('mm_patrons');
            $table->dateTime('dispatch_time')->useCurrent();
            $table->decimal('delivered_qty', 10, 3);

            $table->foreignId('created_by')->nullable()->constrained('mm_users');
            $table->foreignId('updated_by')->nullable()->constrained('mm_users');
            $table->foreignId('deleted_by')->nullable()->constrained('mm_users');

            $table->timestamps();
            $table->softDeletes();

            $table->index('work_order_id');
            $table->index('batch_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mm_dispatches');
    }
};
