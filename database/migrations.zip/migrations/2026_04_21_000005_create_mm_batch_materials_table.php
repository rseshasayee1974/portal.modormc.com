<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mm_batch_materials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('batch_id')->constrained('mm_batches')->cascadeOnDelete();
            $table->foreignId('product_id')->constrained('mm_products');
            $table->string('material_name');
            $table->decimal('target_qty', 12, 3);
            $table->decimal('actual_qty', 12, 3);
            $table->decimal('deviation_percent', 6, 2)->storedAs('(actual_qty - target_qty) / NULLIF(target_qty, 0) * 100');
            $table->foreignId('uom_id')->constrained('mm_product_units');

            $table->foreignId('created_by')->nullable()->constrained('mm_users');
            $table->foreignId('updated_by')->nullable()->constrained('mm_users');
            $table->foreignId('deleted_by')->nullable()->constrained('mm_users');

            $table->timestamps();
            $table->softDeletes();

            $table->index(['batch_id', 'material_name']);
            $table->index('deviation_percent');
            $table->check('deviation_percent between -100.00 and 100.00');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mm_batch_materials');
    }
};
