<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $tables = [
            'patrons', 
            'machines', 
            'taxes', 
            'products', 
            'product_categories',
        ];

        foreach ($tables as $table) {
            Schema::table($table, function (Blueprint $tableLayout) use ($table) {
                if (!Schema::hasColumn($table, 'plant_id')) {
                    $tableLayout->foreignId('plant_id')->after('id')->nullable()->constrained('plants')->nullOnDelete();
                }
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
         $tables = [
            'patrons', 
            'machines', 
            'taxes', 
            'products', 
            'product_categories',
        ];

        foreach ($tables as $table) {
            Schema::table($table, function (Blueprint $tableLayout) {
                $tableLayout->dropForeign(['plant_id']);
                $tableLayout->dropColumn('plant_id');
            });
        }
    }
};
