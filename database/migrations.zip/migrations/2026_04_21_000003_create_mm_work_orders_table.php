<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mm_work_orders', function (Blueprint $table) {
            $table->id();
            $table->string('prefix', 50);
            $table->string('order_no')->unique();
            $table->foreignId('plant_id')->constrained('mm_plants');
            $table->foreignId('customer_id')->constrained('mm_patrons');
            $table->foreignId('site_id')->constrained('mm_sites');
            $table->foreignId('mix_design_id')->constrained('mm_mix_designs');
            $table->decimal('total_qty', 12, 3);
            $table->decimal('produced_qty', 12, 3)->default(0);
            $table->tinyInteger('status')->default(1)->comment('1=Scheduled, 2=InProgress, 3=Completed, 4=Cancelled');
            $table->dateTime('scheduled_start')->nullable();
            $table->dateTime('scheduled_end')->nullable();

            $table->foreignId('created_by')->nullable()->constrained('mm_users');
            $table->foreignId('updated_by')->nullable()->constrained('mm_users');
            $table->foreignId('deleted_by')->nullable()->constrained('mm_users');

            $table->timestamps();
            $table->softDeletes();

            $table->index(['plant_id', 'order_no']);
            $table->index('mix_design_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mm_work_orders');
    }
};
