<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mm_batches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('work_order_id')->constrained('mm_work_orders')->cascadeOnDelete();
            $table->integer('batch_no');
            $table->decimal('batch_size', 5, 2)->default(1.00);
            $table->dateTime('start_time')->nullable();
            $table->dateTime('end_time')->nullable();
            $table->foreignId('truck_id')->constrained('mm_machines');
            $table->tinyInteger('status')->default(1)->comment('1=Planned, 2=Loading, 3=Dispatched, 4=Completed, 5=Cancelled');

            $table->foreignId('created_by')->nullable()->constrained('mm_users');
            $table->foreignId('updated_by')->nullable()->constrained('mm_users');
            $table->foreignId('deleted_by')->nullable()->constrained('mm_users');

            $table->timestamps();
            $table->softDeletes();

            $table->unique(['work_order_id', 'batch_no']);
            $table->index(['work_order_id', 'batch_no']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mm_batches');
    }
};
