<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('roles', function (Blueprint $table) {
            if (!Schema::hasColumn('roles', 'code')) {
                // Add nullable code first
                $table->string('code')->nullable()->after('id');
            }
            if (!Schema::hasColumn('roles', 'description')) {
                $table->text('description')->nullable()->after('name');
            }
            if (!Schema::hasColumn('roles', 'is_system')) {
                $table->boolean('is_system')->default(false)->after('level');
            }
            if (!Schema::hasColumn('roles', 'status')) {
                $table->enum('status', ['active', 'inactive'])->default('active')->after('is_system');
            }
        });

        // Populate code for existing roles to avoid unique constraint violation
        $roles = DB::table('roles')->whereNull('code')->orWhere('code', '')->get();
        foreach ($roles as $role) {
            $code = strtoupper(Str::slug($role->name, '_'));
            // Ensure uniqueness
            $tempCode = $code;
            $counter = 1;
            while (DB::table('roles')->where('code', $tempCode)->exists()) {
                $tempCode = $code . '_' . $counter++;
            }
            DB::table('roles')->where('id', $role->id)->update(['code' => $tempCode]);
        }

        // Add unique constraint and index
        Schema::table('roles', function (Blueprint $table) {
            $table->string('code')->unique()->change();
            if (!DB::select("SHOW INDEX FROM roles WHERE Key_name = 'roles_code_status_index'")) {
                 $table->index(['code', 'status']);
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('roles', function (Blueprint $table) {
            $table->dropColumn(['code', 'description', 'is_system', 'status']);
        });
    }
};
