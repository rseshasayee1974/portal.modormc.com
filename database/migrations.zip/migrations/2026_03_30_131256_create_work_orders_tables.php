<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('work_orders', function (Blueprint $table) {
            $table->id();
            $table->string('work_order_number');
            $table->string('reference_type')->nullable();
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->foreignId('product_id')->nullable()->constrained('products')->nullOnDelete();
            $table->decimal('quantity', 15, 4)->default(0);
            $table->foreignId('uom_id')->nullable()->constrained('product_units')->nullOnDelete();
            $table->dateTime('scheduled_start')->nullable();
            $table->dateTime('scheduled_end')->nullable();
            
            // Audit fields
            $table->tinyInteger('status')->default(1);
            $table->dateTime('created')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->dateTime('modified')->nullable();
            $table->tinyInteger('updated_by')->nullable();
            $table->integer('deleted_by')->nullable();
            
            $table->softDeletes();
        });

        Schema::create('work_order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('work_order_id')->constrained('work_orders')->onDelete('cascade');
            $table->foreignId('material_id')->nullable()->constrained('products')->nullOnDelete();
            $table->decimal('required_qty', 15, 4)->default(0);
            $table->decimal('issued_qty', 15, 4)->default(0);
            $table->foreignId('uom_id')->nullable()->constrained('product_units')->nullOnDelete();
            $table->unsignedBigInteger('location_id')->nullable();

            // Audit fields
            $table->tinyInteger('status')->default(1);
            $table->dateTime('created')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->dateTime('modified')->nullable();
            $table->tinyInteger('updated_by')->nullable();
            $table->integer('deleted_by')->nullable();
            $table->softDeletes();
        });

        Schema::create('work_order_operations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('work_order_id')->constrained('work_orders')->onDelete('cascade');
            $table->string('operation_name');
            $table->integer('sequence')->default(0);
            $table->integer('duration')->nullable(); // in minutes
            $table->dateTime('started_at')->nullable();
            $table->dateTime('completed_at')->nullable();

            // Audit fields
            $table->tinyInteger('status')->default(1);
            $table->dateTime('created')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->dateTime('modified')->nullable();
            $table->tinyInteger('updated_by')->nullable();
            $table->integer('deleted_by')->nullable();
            $table->softDeletes();
        });

        Schema::create('work_order_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('work_order_id')->constrained('work_orders')->onDelete('cascade');
            $table->tinyInteger('status')->nullable();
            $table->text('remarks')->nullable();
            $table->unsignedBigInteger('changed_by')->nullable();
            $table->dateTime('changed_at')->nullable();
            
            // Adding audit fields here too as requested for ALL tables
            $table->dateTime('created')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->dateTime('modified')->nullable();
            $table->tinyInteger('updated_by')->nullable();
            $table->integer('deleted_by')->nullable();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('work_order_logs');
        Schema::dropIfExists('work_order_operations');
        Schema::dropIfExists('work_order_items');
        Schema::dropIfExists('work_orders');
    }
};
