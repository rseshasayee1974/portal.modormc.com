<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Plant;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password;
use OpenApi\Attributes as OA;

class AuthApiController extends Controller
{
    private function canManageBillingApiKey(User $user): bool
    {
        $roles = $user->getRoleNames()->map(fn ($r) => mb_strtolower((string) $r))->all();
        return in_array('saas owner', $roles, true) || in_array('platform admin', $roles, true);
    }

    #[OA\Post(path: "/auth/register", summary: "Register new user", tags: ["Authentication"])]
    #[OA\RequestBody(required: true, content: new OA\JsonContent(properties: [
        new OA\Property(property: "name", type: "string"),
        new OA\Property(property: "email", type: "string"),
        new OA\Property(property: "password", type: "string")
    ]))]
    #[OA\Response(response: 201, description: "Registered successfully")]
    public function register(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:191'],
            'email' => ['required', 'email', 'max:191', 'unique:mm_users,email'],
            'password' => [
                'required', 
                'string', 
                Password::min(8)
                    ->letters()
                    ->mixedCase()
                    ->numbers()
                    ->symbols()
            ],
            // Plan is now defaulted to free on server side for security
        ]);

        $user = User::query()->create([
            'username' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'api_key' => Str::random(60),
            'plan' => 'free', // Default to free on registration
            'is_active' => 1,
        ]);

        return response()->json([
            'message' => 'Registered successfully',
            'user' => [
                'id' => $user->id,
                'name' => $user->username,
                'email' => $user->email,
                'plan' => $user->plan,
                'api_key' => $user->api_key,
            ],
        ], 201);
    }

    #[OA\Post(path: "/login", summary: "Web Login", tags: ["Authentication"])]
    #[OA\RequestBody(required: true, content: new OA\JsonContent(properties: [
        new OA\Property(property: "email", type: "string"),
        new OA\Property(property: "password", type: "string"),
        new OA\Property(property: "remember", type: "boolean")
    ]))]
    #[OA\Response(response: 200, description: "Login Success")]
    public function login(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
            'remember' => ['nullable', 'boolean'],
        ]); 
        $user = User::query()->where('email', $data['email'])->first();
        if (!$user || !Hash::check($data['password'], $user->password)) {
            return response()->json(['message' => 'Invalid email or password.'], 401);
        }

        if (!$user->is_active) {
            return response()->json(['message' => 'Your account is inactive. Please contact support.'], 403);
        }

        if (!$user->api_key) {
            $user->forceFill(['api_key' => Str::random(60)])->save();
        }

        if ($user->is_otp_enabled) {
            return response()->json([
                'message' => 'Two-factor authentication required.',
                '2fa_required' => true,
                'email' => $user->email,
            ], 200); // Or 403/401 depending on frontend preference, but 200 with status is common for SPA
        }

        Auth::login($user, (bool) ($data['remember'] ?? false));
        $token = $user->createToken('web-login')->plainTextToken;
        $user->forceFill(['last_login' => now()])->save();

        return response()->json([
            'message' => 'Logged in successfully',
            'token' => $token,
            'token_type' => 'Bearer',
            'redirect_to' => '/dashboard',
            'user' => [
                'id' => $user->id,
                'name' => $user->username,
                'email' => $user->email,
                'plan' => $user->plan,
                'api_key' => $user->api_key,
                'email_verified_at' => $user->email_verified_at,
                'plants' => $this->getPlantsForUser($user),
            ],
        ]);
    }

    #[OA\Post(path: "/send-otp", summary: "Send OTP to email", tags: ["Authentication"])]
    #[OA\RequestBody(required: true, content: new OA\JsonContent(properties: [
        new OA\Property(property: "email", type: "string")
    ]))]
    #[OA\Response(response: 200, description: "OTP sent")]
    public function sendOtp(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => ['required', 'email', 'exists:mm_users,email'],
        ]);

        $user = User::query()->where('email', $data['email'])->firstOrFail();
        $otp = (string) random_int(100000, 999999);

        Cache::put($this->otpCacheKey($user->email), Hash::make($otp), now()->addMinutes(5));

        if (app()->environment('local')) {
            Log::info("[EMAIL OTP] User {$user->email} code: {$otp} (expires in 5 minutes)");
        }

        return response()->json([
            'message' => 'A 6-digit verification code has been sent.',
            'expires_in' => 300,
        ]);
    }

    #[OA\Post(path: "/verify-otp", summary: "Verify email OTP", tags: ["Authentication"])]
    #[OA\RequestBody(required: true, content: new OA\JsonContent(properties: [
        new OA\Property(property: "email", type: "string"),
        new OA\Property(property: "otp", type: "string")
    ]))]
    #[OA\Response(response: 200, description: "OTP verified")]
    public function verifyOtp(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => ['required', 'email', 'exists:mm_users,email'],
            'otp' => ['required', 'digits:6'],
        ]);

        $user = User::query()->where('email', $data['email'])->firstOrFail();
        $cachedOtp = Cache::get($this->otpCacheKey($user->email));

        if (!$cachedOtp || !Hash::check($data['otp'], $cachedOtp)) {
            return response()->json(['message' => 'The verification code is invalid or expired.'], 422);
        }

        Cache::forget($this->otpCacheKey($user->email));

        if (!$user->hasVerifiedEmail()) {
            $user->forceFill(['email_verified_at' => now()])->save();
        }

        Auth::login($user);
        $token = $user->createToken('email-otp-verification')->plainTextToken;

        return response()->json([
            'message' => 'Email verified successfully.',
            'token' => $token,
            'token_type' => 'Bearer',
            'redirect_to' => '/dashboard',
            'user' => [
                'id' => $user->id,
                'name' => $user->username,
                'email' => $user->email,
                'email_verified_at' => $user->email_verified_at,
                'plants' => $this->getPlantsForUser($user),
            ],
        ]);
    }

    #[OA\Post(path: "/api/resend-verification-email", summary: "Resend verification email", tags: ["Authentication"])]
    #[OA\RequestBody(required: true, content: new OA\JsonContent(properties: [
        new OA\Property(property: "email", type: "string")
    ]))]
    #[OA\Response(response: 200, description: "Email sent")]
    public function resendVerificationEmail(Request $request): JsonResponse
    {
        $data = $request->validate([
            'email' => ['required', 'email', 'exists:mm_users,email'],
        ]);

        $user = User::query()->where('email', $data['email'])->firstOrFail();

        if ($user->hasVerifiedEmail()) {
            return response()->json(['message' => 'This email address is already verified.']);
        }

        $user->sendEmailVerificationNotification();

        return response()->json([
            'message' => 'A fresh verification email has been sent.',
        ]);
    }

    #[OA\Post(path: "/auth/regenerate-key", summary: "Regenerate SaaS API Key", tags: ["SaaS"], security: [["bearerAuth" => []]])]
    #[OA\Response(response: 200, description: "Key regenerated")]
    public function regenerateApiKey(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        abort_unless($this->canManageBillingApiKey($user), 403, 'Only SaaS Owner or Platform Admin can regenerate API key.');
        $user->forceFill(['api_key' => Str::random(60)])->save();

        return response()->json([
            'message' => 'API key regenerated',
            'api_key' => $user->api_key,
        ]);
    }

    #[OA\Get(path: "/auth/ensure-key", summary: "Ensure SaaS API Key exists", tags: ["SaaS"], security: [["bearerAuth" => []]])]
    #[OA\Response(response: 200, description: "Key ensured")]
    public function ensureApiKey(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        abort_unless($this->canManageBillingApiKey($user), 403, 'Only SaaS Owner or Platform Admin can generate API key.');

        if (!$user->api_key) {
            $user->forceFill(['api_key' => Str::random(60)])->save();
        }

        return response()->json([
            'api_key' => $user->api_key,
            'plan' => $user->plan,
        ]);
    }

    private function getPlantsForUser(User $user)
    {
        if ($user->isSystemAdmin()) {
            return Plant::select('id', 'name as plant_name')->get();
        }
        
        $authorizedPlantIds = $user->entityUsers()
            ->whereNotNull('plant_id')
            ->pluck('plant_id')
            ->unique()
            ->toArray();
            
        return Plant::whereIn('id', $authorizedPlantIds)->select('id', 'name as plant_name')->get();
    }

    private function otpCacheKey(string $email): string
    {
        return 'email_otp:'.mb_strtolower($email);
    }
}