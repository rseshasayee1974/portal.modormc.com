<?php

namespace App\Services;

use App\Models\Accounts;
use App\Models\AccountsType;
use App\Models\Ledger;
use App\Models\Plant;
use App\Models\Tax;
use App\Models\AccountDefaultSetting;
use App\Models\Module;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductUnit;
use App\Models\MachineType;
use App\Models\ConcreteGrade;
use App\Models\ConcreteGradeItem;
use App\Models\MixDesign;
use App\Models\MixDesignItem;
use App\Models\Patron;
use App\Models\Site;
use App\Models\Department;
use App\Models\Designation;
use App\Models\LeaveType;
use App\Models\Shift;
use App\Models\SalaryComponent;
use App\Models\StatutoryConfig;
use App\Models\PrintTemplate;
use App\Models\Contact;
use App\Models\EntityUser;
use Spatie\Permission\Models\Role;
use App\Models\User;
use App\Models\VoucherType;
use App\Models\PaymentMethod;
use App\Models\CustomSetting;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

use Illuminate\Support\Facades\Mail;

class PlantInitializationService
{
    public function initialize(Plant $plant)
    {
        if ($plant->is_initialized) {
            return false;
        }

        $oldActivePlantId = Session::get('active_plant_id');
        $oldActiveEntityId = Session::get('active_entity_id');

        Session::put('active_plant_id', $plant->id);
        Session::put('active_entity_id', $plant->entity_id);

        try {
            return DB::transaction(function () use ($plant) {
                $this->seedModules();
                $this->seedAccounting($plant);
                $this->seedTaxes($plant);
                $this->seedAccountDefaultSettings($plant);
                $this->seedProductsAndCategories($plant);
                $this->seedMachineTypes($plant);
                $this->seedConcreteGradesAndMixDesign($plant);
                $this->seedPatron($plant);
                $this->seedSite($plant);
                $this->seedTemplates($plant);
                // $this->seedVoucherTypes($plant);
                // $this->seedPaymentMethods();
                $this->seedCustomSettings($plant);
                $this->seedDepartments($plant);
                $this->seedDesignations($plant);
                $this->seedLeaveTypes($plant);
                $this->seedShifts($plant);
                $this->seedSalaryComponents($plant);
                $this->seedStatutoryConfigs($plant);
                $this->createUserForPlant($plant);

                $plant->update(['is_initialized' => true]);
                return true;
            });
        } finally {
            if ($oldActivePlantId !== null) {
                Session::put('active_plant_id', $oldActivePlantId);
            } else {
                Session::forget('active_plant_id');
            }

            if ($oldActiveEntityId !== null) {
                Session::put('active_entity_id', $oldActiveEntityId);
            } else {
                Session::forget('active_entity_id');
            }
        }
    }

    private function createUserForPlant(Plant $plant)
    {
        if (empty($plant->email_address)) {
            return;
        }

        $password = Str::random(8);
        
        $user = $this->updateOrCreateWithTrashed(
            User::class,
            ['email' => $plant->email_address],
            [
                'username' => $plant->name . ' Admin',
                'password' => Hash::make($password),
                'mobile' => $plant->mobile,
                'is_active'=>1,
                'is_otp_enabled'=>0,
                'created_at'=> now(),
                'created_by'=> Auth::id() ?? 1,
                'email_verified_at' => null,
            ]
        );

        $role = Role::where('name', 'Administrator')->first();
        if ($role) {
            $user->assignRole($role);
        }

        $this->updateOrCreateWithTrashed(
            EntityUser::class,
            [
                'user_id' => $user->id,
                'entity_id' => $plant->entity_id,
                'plant_id' => $plant->id,
            ], [
                'role_id' => $role ? $role->id : 3, // Defaulting to 3 if role not found
                'created_by' => Auth::id() ?? 1,
            ]
        );

        // Email sending is now handled by a separate method
        // to allow manual triggering from the UI.
    }

    public function sendPlantCredentials(Plant $plant, string $password)
    {
        if (empty($plant->email_address)) {
            return false;
        }

        try {
            $loginUrl = url('/');
            Mail::send('emails.plant_credentials', [
                'plant' => $plant,
                'password' => $password,
                'loginUrl' => $loginUrl,
            ], function ($message) use ($plant) {
                $message->to($plant->email_address)
                    ->subject("Plant Access Created: {$plant->name}");
            });
            return true;
        } catch (\Exception $e) {
            \Log::error("Failed to send plant initialization email: " . $e->getMessage());
            return false;
        }
    }

    private function seedModules()
    {
        $modules = [
            ['module_name' => 'Invoice', 'display_value' => 'Sales Invoicing'],
            ['module_name' => 'Purchase', 'display_value' => 'Purchase Billing'],
            ['module_name' => 'Payment', 'display_value' => 'Payments'],
            ['module_name' => 'Receipt', 'display_value' => 'Receipts'],
            ['module_name' => 'Inventory', 'display_value' => 'Inventory Management'],
            ['module_name' => 'Patron', 'display_value' => 'Patron Ledgers'],
        ];

        foreach ($modules as $module) {
            $this->updateOrCreateWithTrashed(
                Module::class,
                ['module_name' => $module['module_name']],
                [
                    'display_value' => $module['display_value'],
                    'is_active' => true,
                ]
            );
        }
    }

    private function seedAccounting(Plant $plant)
    {
        $schema = [
            'ASSET' => [
                'code' => '1000',
                'subgroups' => [
                    'Current Assets' => [
                        'code' => '1100',
                        'ledgers' => [
                            ['code' => '1101', 'title' => 'Cash in Hand', 'is_pnl' => false],
                            ['code' => '1102', 'title' => 'Main Bank Account', 'is_pnl' => false],
                            ['code' => '1103', 'title' => 'Sundry Debtors', 'is_pnl' => false],
                            ['code' => '1104', 'title' => 'Inventory/Stock', 'is_pnl' => false],
                        ]
                    ],
                    'Fixed Assets' => [
                        'code' => '1200',
                        'ledgers' => [
                            ['code' => '1201', 'title' => 'Plant & Machinery', 'is_pnl' => false],
                            ['code' => '1202', 'title' => 'Land & Buildings', 'is_pnl' => false],
                        ]
                    ],
                ]
            ],
            'LIABILITY' => [
                'code' => '2000',
                'subgroups' => [
                    'Current Liabilities' => [
                        'code' => '2100',
                        'ledgers' => [
                            ['code' => '2101', 'title' => 'Sundry Creditors', 'is_pnl' => false],
                            ['code' => '2103', 'title' => 'Outstanding Expenses', 'is_pnl' => false],
                        ]
                    ],
                    'Duties & Taxes' => [
                        'code' => '2400',
                        'ledgers' => [
                            ['code' => '2401', 'title' => 'Output CGST', 'is_pnl' => false],
                            ['code' => '2402', 'title' => 'Output SGST', 'is_pnl' => false],
                            ['code' => '2403', 'title' => 'Output IGST', 'is_pnl' => false],
                            ['code' => '2404', 'title' => 'Input CGST', 'is_pnl' => false],
                            ['code' => '2405', 'title' => 'Input SGST', 'is_pnl' => false],
                            ['code' => '2406', 'title' => 'Input IGST', 'is_pnl' => false],
                            ['code' => '2407', 'title' => 'TDS Payable', 'is_pnl' => false],
                            ['code' => '2408', 'title' => 'TDS Receivable', 'is_pnl' => false],
                        ]
                    ],
                    'Loans (Liability)' => [
                        'code' => '2200',
                        'ledgers' => [
                            ['code' => '2201', 'title' => 'Bank Loans', 'is_pnl' => false],
                        ]
                    ],
                ]
            ],
            'EQUITY' => [
                'code' => '3000',
                'subgroups' => [
                    'Capital Account' => [
                        'code' => '3100',
                        'ledgers' => [
                            ['code' => '3101', 'title' => 'Owner Capital A/c', 'is_pnl' => false],
                        ]
                    ],
                ]
            ],
            'REVENUE' => [
                'code' => '4000',
                'subgroups' => [
                    'Sales Accounts' => [
                        'code' => '4100',
                        'ledgers' => [
                            ['code' => '4101', 'title' => 'Sales Account', 'is_pnl' => true],
                        ]
                    ],
                ]
            ],
            'INCOME' => [
                'code' => '4300',
                'subgroups' => [
                    'Indirect Income' => [
                        'code' => '4301',
                        'ledgers' => [
                            ['code' => '4302', 'title' => 'Other Income', 'is_pnl' => true],
                            ['code' => '4303', 'title' => 'Discount Received', 'is_pnl' => true],
                        ]
                    ],
                ]
            ],
            'EXPENSE' => [
                'code' => '5000',
                'subgroups' => [
                    'Purchase Accounts' => [
                        'code' => '5100',
                        'ledgers' => [
                            ['code' => '5101', 'title' => 'Purchase Account', 'is_pnl' => true],
                        ]
                    ],
                    'Direct Expenses' => [
                        'code' => '5200',
                        'ledgers' => [
                            ['code' => '5201', 'title' => 'Freight & Forwarding', 'is_pnl' => true],
                            ['code' => '5202', 'title' => 'Round Off Account', 'is_pnl' => true],
                            ['code' => '5203', 'title' => 'Adjustment Account', 'is_pnl' => true],
                          
                        ]
                    ],
                    'Indirect Expenses' => [
                        'code' => '5300',
                        'ledgers' => [
                            ['code' => '5301', 'title' => 'Discount Allowed', 'is_pnl' => true],
                            ['code' => '5302', 'title' => 'Office Expenses', 'is_pnl' => true],
                        ]
                    ],
                ]
            ],
        ];

        foreach ($schema as $groupTitle => $groupData) {
            $account = $this->updateOrCreateWithTrashed(
                Accounts::class,
                ['code' => $groupData['code'], 'is_system' => true],
                [
                    'title'     => $groupTitle,
                    'status'    => 1,
                    'created_by' => Auth::id() ?? 1,
                    'created'   => now(),
                ]
            );

            foreach ($groupData['subgroups'] as $subGroupTitle => $subGroupData) {
                $accountType = $this->updateOrCreateWithTrashed(
                    AccountsType::class,
                    ['code' => $subGroupData['code'], 'plant_id' => $plant->id],
                    [
                        'account_id' => $account->id,
                        'title'      => $subGroupTitle,
                        'is_system'  => true,
                        'status'     => 1,
                        'created_by' => Auth::id() ?? 1,
                        'created_at' => now(),
                    ]
                );

                foreach ($subGroupData['ledgers'] as $ledgerData) {
                    $this->updateOrCreateWithTrashed(
                        Ledger::class,
                        ['code' => $ledgerData['code'], 'plant_id' => $plant->id],
                        [
                            'account_type_id' => $accountType->id,
                            'title'           => $ledgerData['title'],
                            'slug'            => Str::slug($ledgerData['title']),
                            'is_pnl'          => $ledgerData['is_pnl'],
                            'is_system'       => true,
                            'status'          => 1,
                            'created_by'      => Auth::id() ?? 1,
                            'created_at'      => now(),
                        ]
                    );
                }
            }
        }
    }

    private function seedTaxes(Plant $plant)
    {
        // --- GST Slabs (Sales) ---
        $slabs = [0, 5, 12, 18, 28];

        foreach ($slabs as $rate) {
            if ($rate == 0) {
                // Create both Exempt and Nil Rated for 0%
                $types = ['Exempt', 'Nil Rated'];
                foreach ($types as $type) {
                    $this->updateOrCreateWithTrashed(
                        Tax::class,
                        [
                            'plant_id' => $plant->id,
                            'tax_name' => "GST $rate% ($type) (Sales)",
                        ], [
                            'entity_id' => $plant->entity_id,
                            'tax_type' => 'sales',
                            'tax_group' => 'GST',
                            'tax_rate' => $rate,
                            'parent_id' => null,
                            'is_system' => true,
                            'status' => 1,
                        ]
                    );
                }
                continue;
            }

            // Root GST (Combined)
            $gstRoot = $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "GST $rate% (Sales)",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'sales',
                    'tax_group' => 'GST',
                    'tax_rate' => $rate,
                    'parent_id' => null,
                    'is_system' => true,
                    'status' => 1,
                ]
            );

            // CGST (Child)
            $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "CGST " . ($rate/2) . "%",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'sales',
                    'tax_group' => 'CGST',
                    'tax_rate' => $rate/2,
                    'parent_id' => $gstRoot->id,
                    'is_system' => true,
                    'status' => 1,
                ]
            );

            // SGST (Child)
            $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "SGST " . ($rate/2) . "%",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'sales',
                    'tax_group' => 'SGST',
                    'tax_rate' => $rate/2,
                    'parent_id' => $gstRoot->id,
                    'is_system' => true,
                    'status' => 1,
                ]
            );

            // IGST (Separate Parent)
            $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "IGST $rate%",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'sales',
                    'tax_group' => 'IGST',
                    'tax_rate' => $rate,
                    'parent_id' => null,
                    'is_system' => true,
                    'status' => 1,
                ]
            );
        }

        // --- GST Slabs (Purchase) ---
        foreach ($slabs as $rate) {
            if ($rate == 0) {
                $types = ['Exempt', 'Nil Rated'];
                foreach ($types as $type) {
                    $this->updateOrCreateWithTrashed(
                        Tax::class,
                        [
                            'plant_id' => $plant->id,
                            'tax_name' => "GST $rate% ($type) (Purchase)",
                        ], [
                            'entity_id' => $plant->entity_id,
                            'tax_type' => 'purchase',
                            'tax_group' => 'GST',
                            'tax_rate' => $rate,
                            'parent_id' => null,
                            'is_system' => true,
                            'status' => 1,
                        ]
                    );
                }
                continue;
            }

            $rootPurchase = $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "GST $rate% (Purchase)",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'purchase',
                    'tax_group' => 'GST',
                    'tax_rate' => $rate,
                    'parent_id' => null,
                    'is_system' => true,
                    'status' => 1,
                ]
            );

            $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "CGST " . ($rate/2) . "% (Purchase)",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'purchase',
                    'tax_group' => 'CGST',
                    'tax_rate' => $rate/2,
                    'parent_id' => $rootPurchase->id,
                    'is_system' => true,
                    'status' => 1,
                ]
            );

            $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "SGST " . ($rate/2) . "% (Purchase)",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'purchase',
                    'tax_group' => 'SGST',
                    'tax_rate' => $rate/2,
                    'parent_id' => $rootPurchase->id,
                    'is_system' => true,
                    'status' => 1,
                ]
            );

            // IGST Purchase (Separate Parent)
            $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "IGST $rate% (Purchase)",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'purchase',
                    'tax_group' => 'IGST',
                    'tax_rate' => $rate,
                    'parent_id' => null,
                    'is_system' => true,
                    'status' => 1,
                ]
            );
        }

        // --- TDS Slabs ---
        $tdsSlabs = [
            ['name' => 'Rent', 'rate' => 10.00],
            ['name' => 'Contractor', 'rate' => 1.00],
            ['name' => 'Professional', 'rate' => 2.00],
            ['name' => 'Purchase of Goods (194Q)', 'rate' => 0.10],
        ];

        foreach ($tdsSlabs as $tds) {
            $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "TDS {$tds['rate']}% ({$tds['name']})",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'purchase',
                    'tax_group' => 'TDS',
                    'tax_rate' => $tds['rate'],
                    'parent_id' => null,
                    'is_system' => true,
                    'status' => 1,
                ]
            );
        }

        // --- TCS Slabs ---
        $tcsSlabs = [
            ['name' => 'Sale of Goods (206C 1H)', 'rate' => 0.10],
            ['name' => 'Scrap', 'rate' => 1.00],
        ];

        foreach ($tcsSlabs as $tcs) {
            $this->updateOrCreateWithTrashed(
                Tax::class,
                [
                    'plant_id' => $plant->id,
                    'tax_name' => "TCS {$tcs['rate']}% ({$tcs['name']})",
                ], [
                    'entity_id' => $plant->entity_id,
                    'tax_type' => 'sales',
                    'tax_group' => 'TCS',
                    'tax_rate' => $tcs['rate'],
                    'parent_id' => null,
                    'is_system' => true,
                    'status' => 1,
                ]
            );
        }

        // --- CESS ---
        $this->updateOrCreateWithTrashed(
            Tax::class,
            [
                'plant_id' => $plant->id,
                'tax_name' => "Compensation Cess 1%",
            ], [
                'entity_id' => $plant->entity_id,
                'tax_type' => 'sales',
                'tax_group' => 'CESS',
                'tax_rate' => 1.00,
                'parent_id' => null,
                'is_system' => true,
                'status' => 1,
            ]
        );
    }

    private function seedAccountDefaultSettings(Plant $plant)
    {
        $mappings = [
            'Invoice' => [
                'sales_account'     => 'Sales Account',
                'cgst_output'       => 'Output CGST',
                'sgst_output'       => 'Output SGST',
                'igst_output'       => 'Output IGST',
                'shipping_account'  => 'Freight & Forwarding',
                'round_off_account' => 'Round Off Account',
                'adjustment_account'=> 'Adjustment Account',
                'tds_receivable'    => 'TDS Receivable',
            ],
            'Purchase' => [
                'purchase_account'  => 'Purchase Account',
                'cgst_input'        => 'Input CGST',
                'sgst_input'        => 'Input SGST',
                'igst_input'        => 'Input IGST',
                'shipping_account'  => 'Freight & Forwarding',
                'round_off_account' => 'Round Off Account',
                'tds_payable'       => 'TDS Payable',
            ],
            'Payment' => [
                'cash_account'      => 'Cash in Hand',
                'bank_account'      => 'Main Bank Account',
                'discount_allowed'  => 'Discount Allowed',
            ],
            'Receipt' => [
                'cash_account'      => 'Cash in Hand',
                'bank_account'      => 'Main Bank Account',
                'discount_received' => 'Discount Received',
            ],
            'Patron' => [
                'debit_ledger'      => 'Sundry Debtors',
                'credit_ledger'     => 'Sundry Creditors',
            ],
        ];

        foreach ($mappings as $moduleName => $keys) {
            $module = Module::where('module_name', $moduleName)->first();
            if (!$module) continue;

            foreach ($keys as $key => $ledgerTitle) {
                $ledger = Ledger::where('plant_id', $plant->id)
                    ->where('title', $ledgerTitle)
                    ->first();

                if ($ledger) {
                    $this->updateOrCreateWithTrashed(
                        AccountDefaultSetting::class,
                        [
                            'plant_id'    => $plant->id,
                            'module_id'   => $module->id,
                            'setting_key' => $key,
                        ],
                        [
                            'module_name' => $module->module_name,
                            'ledger_id'   => $ledger->id,
                            'is_system'   => true,
                            'is_active'   => true,
                        ]
                    );
                }
            }
        }
    }

    private function seedProductsAndCategories(Plant $plant)
    {
        $kgUnit = ProductUnit::where('unit_code', 'KGS')->first() ?? ProductUnit::create(['unit_name' => 'KGS', 'unit_code' => 'KGS', 'unit_type' => 'Weight', 'is_system' => true, 'status' => 1]);
        $m3Unit = ProductUnit::where('unit_code', 'CBM')->first() ?? ProductUnit::create(['unit_name' => 'CBM', 'unit_code' => 'CBM', 'unit_type' => 'Volume', 'is_system' => true, 'status' => 1]);
        $bagUnit = ProductUnit::where('unit_code', 'BAG')->first() ?? ProductUnit::create(['unit_name' => 'BAGS', 'unit_code' => 'BAG', 'unit_type' => 'Measure', 'is_system' => true, 'status' => 1]);
        $nosUnit = ProductUnit::where('unit_code', 'NOS')->first() ?? ProductUnit::create(['unit_name' => 'NUMBERS', 'unit_code' => 'NOS', 'unit_type' => 'Measure', 'is_system' => true, 'status' => 1]);

        $rmcCategory = $this->updateOrCreateWithTrashed(
            ProductCategory::class,
            [
                'plant_id' => $plant->id,
                'name' => 'READY MIX CONCRETE',
            ], [
                'entity_id' => $plant->entity_id,
                'code' => 'RMC',
                'is_system' => true,
                'status' => 1,
            ]
        );

        $categories = [
            'SAND' => '1',
            'AGGREGATES' => '2',
            'CEMENT' => '3',
            'FINE AGGREGATES' => '4',
            'WATER' => '5',
            'ADMIXTURE' => '6',
            'SILICA' => '7',
        ];

        $categoryModels = [];
        foreach ($categories as $name => $code) {
            $categoryModels[$name] = $this->updateOrCreateWithTrashed(
                ProductCategory::class,
                [
                    'plant_id' => $plant->id,
                    'name' => $name,
                ], [
                    'entity_id' => $plant->entity_id,
                    'code' => $code,
                    'is_system' => true,
                    'status' => 1,
                ]
            );
        }

        $this->updateOrCreateWithTrashed(
            Product::class,
            [
                'plant_id' => $plant->id,
                'title' => 'Concrete',
            ], [
                'entity_id' => $plant->entity_id,
                'category_id' => $rmcCategory->id,
                'unit_id' => $m3Unit->id,
                'product_type' =>'Purchase',
                'code' => 'CONC-001',
                'is_system' => true,
                'status' => 1,
            ]
        );

        $products = [
            ['title' => 'Cement OPC 53 Grade', 'cat' => 'CEMENT', 'code' => 'CMT-001' , 'status'=> 0],
            ['title' => 'Crushed Sand (M-Sand)', 'cat' => 'SAND', 'code' => 'SND-001' , 'status'=> 0],
            ['title' => 'Fine Sand', 'cat' => 'FINE AGGREGATES', 'code' => 'FSND-001' , 'status'=> 0],
            ['title' => 'Coarse Aggregate 10mm', 'cat' => 'AGGREGATES', 'code' => 'AGG-010' , 'status'=> 0],
            ['title' => 'Coarse Aggregate 20mm', 'cat' => 'AGGREGATES', 'code' => 'AGG-020' , 'status'=> 0],
            ['title' => 'Water', 'cat' => 'WATER', 'code' => 'WTR-001' , 'status'=> 0],
            ['title' => 'Admixture', 'cat' => 'ADMIXTURE', 'code' => 'ADM-001' , 'status'=> 0],
            ['title' => 'Silica Fume', 'cat' => 'SILICA', 'code' => 'SIL-001' , 'status'=> 0],
        ];

        foreach ($products as $p) {
            $this->updateOrCreateWithTrashed(
                Product::class,
                [
                    'plant_id' => $plant->id,
                    'title' => $p['title'],
                ], [
                    'entity_id' => $plant->entity_id,
                    'category_id' => $categoryModels[$p['cat']]->id,
                    'unit_id' => $kgUnit->id,
                    'code' => $p['code'],
                    'product_type' =>'Purchase',
                    'is_system' => true,
                    'status' => 1,
                ]
            );
        }
    }

    private function seedMachineTypes(Plant $plant)
    {
        $types = ['Truck','Batching Plant', 'Transit Mixer', 'Concrete Pump', 'Loader', 'DG Set'];
        foreach ($types as $type) {
            $this->updateOrCreateWithTrashed(
                MachineType::class,
                [
                    'plant_id' => $plant->id,
                    'name' => $type,
                ], [
                    'is_system' => true,
                ]
            );
        }
    }

    private function seedConcreteGradesAndMixDesign(Plant $plant)
    {       
        $kgUnitId = ProductUnit::where('unit_code', 'KGS')->first()->id ?? 1;
        $m3UnitId = ProductUnit::where('unit_code', 'CBM')->first()->id ?? 1;
        $grades = [
            'M10' => ['ratio' => '1:3:6', 'cement' => 1, 'sand' => 3, 'aggregate' => 6],
            'M15' => ['ratio' => '1:2:4', 'cement' => 1, 'sand' => 2, 'aggregate' => 4],
            'M20' => ['ratio' => '1:1.5:3', 'cement' => 1, 'sand' => 1.5, 'aggregate' => 3],
            'M25' => ['ratio' => '1:1:2', 'cement' => 1, 'sand' => 1, 'aggregate' => 2],
            'M30' => ['ratio' => 'Design Mix', 'cement' => null, 'sand' => null, 'aggregate' => null],
            'M35' => ['ratio' => 'Design Mix', 'cement' => null, 'sand' => null, 'aggregate' => null],
            'M40' => ['ratio' => 'Design Mix', 'cement' => null, 'sand' => null, 'aggregate' => null],
        ];

        foreach ($grades as $gradeName => $data) {
            $grade = $this->updateOrCreateWithTrashed(
                ConcreteGrade::class,
                [
                    'plant_id' => $plant->id,
                    'name' => $gradeName,
                ], [
                    'concrete_code' => "STD-$gradeName",
                    'concrete_ratio' => $data['ratio'],
                    'cement_ratio' => $data['cement'],
                    'sand_ratio' => $data['sand'],
                    'aggregate_ratio' => $data['aggregate'],
                    'is_system' => true,
                    'status' => 1,
                    'created_by' => Auth::id() ?? 1,
                ]
            );

            // Seed some default items for the grade
            $cement = Product::where('plant_id', $plant->id)->where('title', 'like', '%Cement%')->first();
            if ($cement) {
                $this->updateOrCreateWithTrashed(
                    ConcreteGradeItem::class,
                    [
                        'concrete_grade_id' => $grade->id,
                        'product_id' => $cement->id,
                        'plant_id' => $plant->id,
                    ], [
                        'plant_id' => $plant->id,
                        'quantity' => 300,
                        'is_system' => true,
                        'created_by' => Auth::id() ?? 1,
                    ]
                );
            }
        }

        // Default Mix Design
        $patron = Patron::where('plant_id', $plant->id)->first();
        if (!$patron) {
            $this->seedPatron($plant);
            $patron = Patron::where('plant_id', $plant->id)->first();
        }

        $concrete_grade = ConcreteGrade::where('plant_id', $plant->id)->first();
        $mix = $this->updateOrCreateWithTrashed(
            MixDesign::class,
            [
                'concrete_grade_id' => $concrete_grade->id,
                'plant_id' => $plant->id,
                'design_name' => 'Default M25 Design',
            ], [
                'partner_id' => $patron->id,
                'design_code' => 'DEF-M25',
                'design_type' => 'M25',
                'unit_id' => $m3UnitId,
                'rate_per_qty' => 4500,
                'is_system' => true,
                'created_by' => Auth::id() ?? 1,
            ]
        );
    }

    private function seedPatron(Plant $plant)
    {
        $this->updateOrCreateWithTrashed(
            Patron::class,
            [
                'plant_id' => $plant->id,
                'legal_name' => 'Default Customer',
            ], [
                'entity_id' => $plant->entity_id,
                'code' => 'CUST-001',
                'patron_type' => ['Customer'], // The request said 'Customer, Vendor, Transport'
                'is_system' => true,
                'is_active' => true,
                'aadhar_number' => 6556454646456,
                'created_by' => Auth::id() ?? 1,
            ]
        );

        $this->updateOrCreateWithTrashed(
            Patron::class,
            [
                'plant_id' => $plant->id,
                'legal_name' => 'Default Vendor',
            ], [
                'entity_id' => $plant->entity_id,
                'code' => 'VEND-001',
                'patron_type' => ['Vendor'],
                'is_system' => true,
                                'gstin' => 'GSTIN-4646456',

                'is_active' => true,
                'created_by' => Auth::id() ?? 1,
            ]
        );

        $this->updateOrCreateWithTrashed(
            Patron::class,
            [
                'plant_id' => $plant->id,
                'legal_name' => 'Default Transporter',
            ], [
                'entity_id' => $plant->entity_id,
                'code' => 'TRANS-001',
                'patron_type' => ['Transport'],
                'is_system' => true,
                'is_active' => true,
                                'aadhar_number' => 6556454646456,

                'created_by' => Auth::id() ?? 1,
            ]
        );
    }

    private function seedSite(Plant $plant)
    {
        $this->updateOrCreateWithTrashed(
            Site::class,
            [
                'plant_id' => $plant->id,
                'name' => 'Plant Site',
                'type' => 'loading',
            ], [
                'code' => 'PSITE-001',
                'is_system' => true,
                'is_active' => true,
                'created_by' => Auth::id() ?? 1,
            ]
        );
    }

    private function seedDepartments(Plant $plant)
    {
        $departments = [
            ['name' => 'Production',      'code' => 'PROD'],
            ['name' => 'Quality Control', 'code' => 'QC'],
            ['name' => 'Accounts',        'code' => 'ACC'],
            ['name' => 'Human Resources', 'code' => 'HR'],
            ['name' => 'Administration',  'code' => 'ADMIN'],
            ['name' => 'Logistics',       'code' => 'LGS'],
        ];

        foreach ($departments as $dept) {
            $this->updateOrCreateWithTrashed(
                Department::class,
                ['code' => $dept['code']],
                [
                    'name'       => $dept['name'],
                    'created_by' => Auth::id() ?? 1,
                ]
            );
        }
    }

    private function seedDesignations(Plant $plant)
    {
        $designations = [
            ['name' => 'Plant Manager',       'code' => 'PM'],
            ['name' => 'Production Engineer', 'code' => 'PE'],
            ['name' => 'Quality Engineer',    'code' => 'QE'],
            ['name' => 'Accountant',          'code' => 'ACCT'],
            ['name' => 'Operator',            'code' => 'OPR'],
            ['name' => 'Sales Executive',     'code' => 'SE'],
            ['name' => 'Driver',     'code' => 'DRV'],
        ];

        foreach ($designations as $desig) {
            $this->updateOrCreateWithTrashed(
                Designation::class,
                ['code' => $desig['code']],
                [
                    'name'       => $desig['name'],
                    'created_by' => Auth::id() ?? 1,
                ]
            );
        }
    }

    private function seedLeaveTypes(Plant $plant = null)
    {
        $leaveTypes = [
            ['name' => 'Casual Leave',      'is_paid' => true,  'max_days_per_year' => 12, 'carry_forward' => false],
            ['name' => 'Sick Leave',        'is_paid' => true,  'max_days_per_year' => 7,  'carry_forward' => false],
            ['name' => 'Earned Leave',      'is_paid' => true,  'max_days_per_year' => 15, 'carry_forward' => true],
            ['name' => 'Maternity Leave',   'is_paid' => true,  'max_days_per_year' => 180,'carry_forward' => false],
            ['name' => 'Leave Without Pay', 'is_paid' => false, 'max_days_per_year' => 0,  'carry_forward' => false],
        ];

        foreach ($leaveTypes as $lt) {
            $this->updateOrCreateWithTrashed(
                LeaveType::class,
                ['name' => $lt['name']],
                [
                    'is_paid'           => $lt['is_paid'],
                    'max_days_per_year' => $lt['max_days_per_year'],
                    'carry_forward'     => $lt['carry_forward'],
                    'created_by'        => Auth::id() ?? 1,
                ]
            );
        }
    }

    private function seedShifts(Plant $plant = null)
    {
        $shifts = [
            ['shift_name' => 'General Shift', 'start_time' => '09:00', 'end_time' => '18:00', 'grace_time' => 10, 'working_hours' => 9,  'is_night_shift' => false],
            ['shift_name' => 'Morning Shift', 'start_time' => '06:00', 'end_time' => '14:00', 'grace_time' => 10, 'working_hours' => 8,  'is_night_shift' => false],
            ['shift_name' => 'Evening Shift', 'start_time' => '14:00', 'end_time' => '22:00', 'grace_time' => 10, 'working_hours' => 8,  'is_night_shift' => false],
            ['shift_name' => 'Night Shift',   'start_time' => '22:00', 'end_time' => '06:00', 'grace_time' => 10, 'working_hours' => 8,  'is_night_shift' => true],
        ];

        foreach ($shifts as $shift) {
            $this->updateOrCreateWithTrashed(
                Shift::class,
                ['shift_name' => $shift['shift_name']],
                [
                    'start_time'     => $shift['start_time'],
                    'end_time'       => $shift['end_time'],
                    'grace_time'     => $shift['grace_time'],
                    'working_hours'  => $shift['working_hours'],
                    'is_night_shift' => $shift['is_night_shift'],
                    'created_by'     => Auth::id() ?? 1,
                ]
            );
        }
    }

    private function seedSalaryComponents(Plant $plant)
    {
        $components = [
            // Earnings
            ['name' => 'Basic Salary',          'type' => 'earning',   'calculation_type' => 'fixed',      'default_value' => 0,    'is_taxable' => true,  'is_statutory' => false],
            ['name' => 'House Rent Allowance',  'type' => 'earning',   'calculation_type' => 'percentage', 'default_value' => 40,   'is_taxable' => false, 'is_statutory' => false],
            ['name' => 'Conveyance Allowance',  'type' => 'earning',   'calculation_type' => 'fixed',      'default_value' => 1600, 'is_taxable' => false, 'is_statutory' => false],
            ['name' => 'Special Allowance',     'type' => 'earning',   'calculation_type' => 'fixed',      'default_value' => 0,    'is_taxable' => true,  'is_statutory' => false],
            ['name' => 'Overtime',              'type' => 'earning',   'calculation_type' => 'fixed',      'default_value' => 0,    'is_taxable' => true,  'is_statutory' => false],
            // Deductions
            ['name' => 'Provident Fund (PF)',   'type' => 'deduction', 'calculation_type' => 'percentage', 'default_value' => 12,   'is_taxable' => false, 'is_statutory' => true],
            ['name' => 'ESI',                   'type' => 'deduction', 'calculation_type' => 'percentage', 'default_value' => 0.75, 'is_taxable' => false, 'is_statutory' => true],
            ['name' => 'Professional Tax',      'type' => 'deduction', 'calculation_type' => 'fixed',      'default_value' => 200,  'is_taxable' => false, 'is_statutory' => true],
            ['name' => 'TDS',                   'type' => 'deduction', 'calculation_type' => 'fixed',      'default_value' => 0,    'is_taxable' => false, 'is_statutory' => true],
            ['name' => 'Advance Deduction',     'type' => 'deduction', 'calculation_type' => 'fixed',      'default_value' => 0,    'is_taxable' => false, 'is_statutory' => false],
        ];

        foreach ($components as $comp) {
            $this->updateOrCreateWithTrashed(
                SalaryComponent::class,
                ['plant_id' => $plant->id, 'name' => $comp['name']],
                [
                    'type'             => $comp['type'],
                    'calculation_type' => $comp['calculation_type'],
                    'default_value'    => $comp['default_value'],
                    'is_taxable'       => $comp['is_taxable'],
                    'is_statutory'     => $comp['is_statutory'],
                    'created_by'       => Auth::id() ?? 1,
                ]
            );
        }
    }

    private function seedStatutoryConfigs(Plant $plant)
    {
        $configs = [
            [
                'statute_name'   => 'Provident Fund (PF)',
                'effective_from' => now()->startOfYear()->toDateString(),
                'rules'          => [
                    'employee_rate'   => 12,
                    'employer_rate'   => 12,
                    'wage_ceiling'    => 15000,
                    'apply_on'        => 'basic',
                ],
            ],
            [
                'statute_name'   => 'Employee State Insurance (ESI)',
                'effective_from' => now()->startOfYear()->toDateString(),
                'rules'          => [
                    'employee_rate'   => 0.75,
                    'employer_rate'   => 3.25,
                    'wage_ceiling'    => 21000,
                    'apply_on'        => 'gross',
                ],
            ],
        ];

        foreach ($configs as $cfg) {
            $this->updateOrCreateWithTrashed(
                StatutoryConfig::class,
                ['plant_id' => $plant->id, 'statute_name' => $cfg['statute_name']],
                [
                    'effective_from' => $cfg['effective_from'],
                    'rules'          => $cfg['rules'],
                    'created_by'     => Auth::id() ?? 1,
                ]
            );
        }
    }

    private function seedTemplates(Plant $plant)
    {
        if (PrintTemplate::count() === 0) {
            $seeder = new \Database\Seeders\PrintTemplateSeeder();
            $seeder->run();
        }

        $moduleTemplates = [
            'invoices'          => 'standard_indigo',
            'sales_orders'      => 'standard',
            'purchase_orders'   => 'standard_indigo',
            'purchase_bills'    => 'standard',
            'quotations'        => 'standard',
            'customer_pos'      => 'standard',
            'delivery_challans' => 'delivery_challan_a4',
            'delivery_notes'    => 'standard',
            'credit_notes'      => 'standard',
            'statements'        => 'tallysheet',
            'gst_invoices'      => 'indian_gst',
        ];

        foreach ($moduleTemplates as $moduleKey => $templateKey) {
            $template = PrintTemplate::where('key', $templateKey)->first()
                ?? PrintTemplate::where('is_system', true)->first()
                ?? PrintTemplate::first();

            if ($template) {
                $this->updateOrCreateWithTrashed(
                    \App\Models\PrintTemplateSetting::class,
                    [
                        'plant_id'   => $plant->id,
                        'module_key' => $moduleKey,
                    ], [
                        'entity_id'         => $plant->entity_id,
                        'print_template_id' => $template->id,
                    ]
                );
            }
        }
    }

    // private function seedModules()
    // {
    //     $modules = [
    //         ['module_name' => 'Invoice', 'display_value' => 'Sales Invoicing'],
    //         ['module_name' => 'Purchase', 'display_value' => 'Purchase Billing'],
    //         ['module_name' => 'Billing', 'display_value' => 'Purchase Billing'],
    //         ['module_name' => 'Payment', 'display_value' => 'Payments'],
    //         ['module_name' => 'Receipt', 'display_value' => 'Receipts'],
    //         ['module_name' => 'Inventory', 'display_value' => 'Inventory Management'],
    //         ['module_name' => 'Patron', 'display_value' => 'Patron Ledgers'],
    //     ];

    //     foreach ($modules as $module) {
    //         Module::updateOrCreate(
    //             ['module_name' => $module['module_name']],
    //             ['display_value' => $module['display_value'], 'is_active' => true]
    //         );
    //     }
    // }

    // private function seedVoucherTypes(Plant $plant)
    // {
    //     $voucherTypes = [
    //         ['journal_name' => 'General Journal', 'short_code' => 'JV', 'is_system_generated' => true, 'prefix' => 'JV-', 'voucher_group' => 'Other'],
    //         ['journal_name' => 'Purchase Journal', 'short_code' => 'PUR', 'is_system_generated' => true, 'prefix' => 'PUR-', 'voucher_group' => 'Purchase'],
    //         ['journal_name' => 'Vendor Bill', 'short_code' => 'VBILL', 'is_system_generated' => true, 'prefix' => 'VBILL-', 'voucher_group' => 'Purchase'],
    //         ['journal_name' => 'Sales Journal', 'short_code' => 'SALE', 'is_system_generated' => true, 'prefix' => 'SALE-', 'voucher_group' => 'Sales'],
    //         ['journal_name' => 'Payment Journal', 'short_code' => 'PAY', 'is_system_generated' => true, 'prefix' => 'PAY-', 'voucher_group' => 'Payment'],
    //         ['journal_name' => 'Receipt Journal', 'short_code' => 'REC', 'is_system_generated' => true, 'prefix' => 'REC-', 'voucher_group' => 'Receipt'],
    //         ['journal_name' => 'Contra Journal', 'short_code' => 'CON', 'is_system_generated' => false, 'prefix' => 'CON-', 'voucher_group' => 'Other'],
    //         ['journal_name' => 'Debit Note', 'short_code' => 'DN', 'is_system_generated' => true, 'prefix' => 'DN-', 'voucher_group' => 'Debit Note'],
    //         ['journal_name' => 'Credit Note', 'short_code' => 'CN', 'is_system_generated' => true, 'prefix' => 'CN-', 'voucher_group' => 'Credit Note'],
    //         ['journal_name' => 'Tax Invoice', 'short_code' => 'TAX', 'is_system_generated' => true, 'prefix' => 'TAX-', 'voucher_group' => 'Sales'],
    //     ];

    //     foreach ($voucherTypes as $type) {
    //         VoucherType::updateOrCreate(
    //             [
    //                 'short_code' => $type['short_code'],
    //                 'plant_id'   => $plant->id
    //             ],
    //             array_merge($type, [
    //                 'entity_id' => $plant->entity_id,
    //                 'plant_id'  => $plant->id
    //             ])
    //         );
    //     }
    // }

    private function seedPaymentMethods()
    {
        $methods = [
            ['name' => 'Cash', 'description' => 'Cash Payment'],
            ['name' => 'UPI', 'description' => 'Digital Wallet / UPI'],
            ['name' => 'Bank Transfer', 'description' => 'IMPS/NEFT/RTGS'],
            ['name' => 'Check', 'description' => 'Bank Check'],
        ];

        foreach ($methods as $method) {
            PaymentMethod::updateOrCreate(
                [
                    'name'     => $method['name']
                ],
                array_merge($method, [
                    'is_active' => true
                ])
            );
        }
    }

    private function seedCustomSettings(Plant $plant)
    {
        $settings = [
            [
                'module_name' => 'batching',
                'settings' => [
                    'newweight' => 1,
                    'manual_weight' => 1,
                    'camera' => 1,
                    'camera_url' => "",
                    'camera_url_1' => "",
                    'camera_url_2' => "",
                    'loader_gif' => null
                ]
            ],
            [
                'module_name' => 'orders',
                'settings' => [
                    'manualweight' => 1
                ]
            ],
            [
                'module_name' => 'invoices',
                'settings' => [
                    'pdf' => [
                        'company_name' => false,
                        'logo' => true,
                        'address' => true,
                        'phone' => true,
                        'email' => true,
                        'gstin' => true,
                        'invoice_title' => true,
                        'invoice_number' => true,
                        'date' => true,
                        'due_date' => true,
                        'status' => false,
                        'bill_to' => false,
                        'ship_to' => false,
                        'hsn_code' => true,
                        'description' => true,
                        'unit' => true,
                        'discount' => true,
                        'tax_percent' => true,
                        'cgst' => true,
                        'sgst' => true,
                        'igst' => true,
                        'shipping' => true,
                        'round_off' => true,
                        'total_words' => true,
                        'notes' => true,
                        'terms' => true,
                        'signature' => true,
                        'labels' => [
                            'invoice_title' => "TAX INVOICE",
                            'bill_to' => "Bill To",
                            'ship_to' => "Ship To",
                            'rate' => "Rate",
                            'amount' => "Amount"
                        ]
                    ],
                    'excel' => [
                        'hsn_code' => true,
                        'discount' => true
                    ]
                ]
            ],
            [
                'module_name' => 'billing',
                'settings' => [
                    'instant_invoice_patron' => 1,
                    'prefix' => 'BILL/',
                    'next_number' => 1
                ]
            ],
            [
                'module_name' => 'quotation',
                'settings' => [
                    'instant_customer' => 1,
                    'prefix' => 'QTN/',
                    'next_number' => 1
                ]
            ],
            [
                'module_name' => 'purchase',
                'settings' => [
                    'instant_vendor' => 1,
                    'prefix' => 'PO/',
                    'next_number' => 1
                ]
            ],
        ];

        foreach ($settings as $s) {
            $this->updateOrCreateWithTrashed(
                CustomSetting::class,
                ['plant_id' => $plant->id, 'module_name' => $s['module_name']],
                ['settings' => $s['settings']]
            );
        }
    }

    private function updateOrCreateWithTrashed(string $modelClass, array $attributes, array $values = [])
    {
        $query = $modelClass::query()->withoutGlobalScope('plant_id');

        if (in_array(\Illuminate\Database\Eloquent\SoftDeletes::class, class_uses_recursive($modelClass))) {
            $query->withTrashed();
        }

        $record = $query->where($attributes)->first();
        if ($record) {
            if (method_exists($record, 'trashed') && $record->trashed()) {
                $record->restore();
            }
            $record->update($values);
        } else {
            $record = $modelClass::create(array_merge($attributes, $values));
        }
        return $record;
    }
}