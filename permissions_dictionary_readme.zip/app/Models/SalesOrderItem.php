<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SalesOrderItem extends Model
{
        use HasFactory, SoftDeletes;
    
    protected $table = 'mm_sales_order_items';
    public $timestamps = false;

    protected $fillable = [
        'sales_order_id',
        'material_id',
        'required_qty',
        'issued_qty',
        'uom_id',
        'location_id',
        'status',
        'created_by',
        'created',
        'modified',
        'updated_by',
        'deleted_by'
    ];

    public function salesOrder()
    {
        return $this->belongsTo(SalesOrder::class, 'sales_order_id');
    }

    public function material()
    {
        return $this->belongsTo(Product::class, 'material_id');
    }

    public function uom()
    {
        return $this->belongsTo(ProductUnit::class, 'uom_id');
    }

    public function issueMaterial($qty)
    {
        $this->issued_qty += $qty;
        $this->save();
    }
}
