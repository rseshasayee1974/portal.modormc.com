<?php

namespace App\Models;

use App\Http\Controllers\Concerns\AuthorizesModule;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\ProtectsSystemItems;
use App\Traits\TracksModelChanges;
class ConcreteGrade extends Model
{
        use HasFactory, SoftDeletes, ProtectsSystemItems, TracksModelChanges;
    protected $table = 'mm_concrete_grades';
    protected $fillable = [
        'plant_id',
        'name',
        'concrete_code',
        'concrete_ratio',
        'cement_ratio',
        
        'sand_ratio',
        'aggregate_ratio',
        'is_system',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected $casts = [
        'status' => 'boolean',
        'is_system' => 'boolean',
        'cement_ratio' => 'decimal:2',
        'sand_ratio' => 'decimal:2',
        'aggregate_ratio' => 'decimal:2',
    ];



    protected static function booted()
    {
        static::deleting(function ($concreteGrade) {
            foreach ($concreteGrade->items as $item) {
                $item->delete();
            }
        });
    }

    public function plant()
    {
        return $this->belongsTo(Plant::class, 'plant_id');
    }

    public function items()
    {
        return $this->hasMany(ConcreteGradeItem::class);
    }
    public function mixDesigns()
    {
        return $this->hasMany(MixDesign::class);
    }
    
}
